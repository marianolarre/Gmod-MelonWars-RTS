ENT.Type = "anim"
ENT.Base = "ent_melon_base"
 
ENT.Category = "Marums pack"

ENT.PrintName= "Melon Mortar Barracks"
ENT.Author= "Marum"
ENT.Contact= "don`t"
ENT.Purpose= "Annoy"
ENT.Instructions= "Spawn a whole bunch"
ENT.Spawnable = false
ENT.AdminSpawnable = false