ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.Category = "MelonWars"

ENT.PrintName= "Melon Base Prop"
ENT.Author= "Marum"
ENT.Contact= "don`t"
ENT.Purpose= "Annoy"
ENT.Instructions= "Spawn a whole bunch"
ENT.Spawnable = false
ENT.AdminSpawnable = false