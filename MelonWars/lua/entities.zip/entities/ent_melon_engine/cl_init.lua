include('shared.lua')

--function ENT:Draw()
    -- self.BaseClass.Draw(self) -- Overrides Draw
--    self:DrawModel() -- Draws Model Client Side
--end