include('shared.lua')

function ENT:Draw()
    self:DrawModel() -- Draws Model Client Side
end