ENT.Type = "anim"
ENT.Base = "ent_melon_base"
 
ENT.Category = "MelonWars"

ENT.PrintName= "Melon Main Building"
ENT.Author= "Marum"
ENT.Contact= "don`t"
ENT.Purpose= "Annoy"
ENT.Instructions= "Spawn 1 per team"
ENT.Spawnable = false
ENT.AdminSpawnable = false