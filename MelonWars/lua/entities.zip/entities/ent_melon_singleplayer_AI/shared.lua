ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.Category = "MelonWars Level Editor"

ENT.PrintName= "SinglePlayer AI"
ENT.Author= "Marum"
ENT.Contact= ""
ENT.Purpose= ""
ENT.Instructions= ""
ENT.Spawnable = false
ENT.AdminSpawnable = false