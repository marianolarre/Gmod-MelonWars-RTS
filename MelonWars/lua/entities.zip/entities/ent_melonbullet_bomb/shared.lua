ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.Category = "Marums pack"

ENT.PrintName= "Melon Mortar Bomb"
ENT.Author= "Marum"
ENT.Contact= "boom"
ENT.Purpose= "boom"
ENT.Instructions= "boom"
ENT.Spawnable = false
ENT.AdminSpawnable = false