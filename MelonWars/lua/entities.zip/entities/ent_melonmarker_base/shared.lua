ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.Category = "MelonWars Level Editor"

ENT.PrintName= "Melon Marker Base"
ENT.Author= "Marum"
ENT.Contact= "don`t"
ENT.Purpose= "Annoy"
ENT.Instructions= "Spawn a whole bunch"
ENT.Spawnable = false
ENT.AdminSpawnable = false